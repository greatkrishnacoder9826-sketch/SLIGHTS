"""
Cinematic Pixel-by-Pixel Photo Reveal Animation
=================================================

Reconstructs a photograph from thousands of tiny pixel-blocks in a
premium, cinematic animation, then displays it in full quality with
an emotional caption underneath.

Usage:
    pip install -r requirements.txt
    python main.py

Controls (while the window is focused):
    ESC   -> Exit
    SPACE -> Restart the animation
    S     -> Save a screenshot of the current frame
    F     -> Toggle fullscreen
    V     -> Export the animation to output/sister_reveal.mp4
"""

import os
import sys
import math
import random
import time

import numpy as np
import pygame
from PIL import Image

# ----------------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------------

# Path to the source photograph. Replace this file with your own photo.
IMAGE_PATH = "assets/sister.jpg"

# How long (in seconds) the pixel-reveal stage takes, before the
# final high-quality image snaps into place.
REVEAL_DURATION = 12

# Size (in screen pixels) of each reveal "block". Smaller = more
# blocks = finer, slower-feeling reveal but higher fidelity motion.
# This only affects the *reveal animation*; the final image is always
# shown at full source resolution.
PIXEL_SIZE = 4

# Target frame rate for the live animation.
FPS = 60

# Brightness (0-255) of the background canvas during Stage 1/2.
BACKGROUND_BRIGHTNESS = 5

# Toggle optional visual effects.
SHOW_PARTICLES = True
SHOW_GLOW = True

# Caption shown beneath the completed photograph.
FINAL_TEXT = "My Sister, My Love"

# Number of ambient background particles (Stage 1 atmosphere).
PARTICLE_COUNT = 500

# How long (seconds) the completed photo + text stay on screen
# before the loop simply holds (user can still restart with SPACE).
HOLD_DURATION = 6

# Seconds spent fading the caption in after the photo completes.
TEXT_FADE_DURATION = 2.5

# Output video path if the user exports the animation.
EXPORT_PATH = "output/sister_reveal.mp4"
EXPORT_FPS = 60


# ----------------------------------------------------------------------
# IMAGE LOADING
# ----------------------------------------------------------------------

def load_image(path):
    """Load the source photograph at full quality, preserving color and
    aspect ratio. Returns an RGB numpy array (H, W, 3) uint8."""
    if not os.path.exists(path):
        print("Image not found.")
        print("Please place your photograph inside:")
        print("    assets/sister.jpg")
        sys.exit(1)

    try:
        img = Image.open(path)
        img = img.convert("RGB")  # drop alpha / palette, preserve color
    except Exception as exc:
        print(f"Could not open the image file: {exc}")
        sys.exit(1)

    return np.array(img)  # (H, W, 3) uint8, full original resolution


def compute_display_size(img_w, img_h):
    """Pick the best display resolution (capped at the desktop size)
    while preserving the photo's aspect ratio, then compute the
    letterboxed target rect within that window."""
    info = pygame.display.Info()
    desktop_w, desktop_h = info.current_w, info.current_h

    # Prefer common resolutions, capped to what the desktop can show.
    candidates = [(3840, 2160), (2560, 1440), (1920, 1080)]
    win_w, win_h = 1920, 1080
    for cw, ch in candidates:
        if cw <= desktop_w and ch <= desktop_h:
            win_w, win_h = cw, ch
            break
    else:
        win_w, win_h = min(1920, desktop_w), min(1080, desktop_h)

    # Fit the image into the window without stretching (letterbox/pillarbox).
    scale = min(win_w / img_w, win_h / img_h)
    fit_w, fit_h = int(img_w * scale), int(img_h * scale)
    off_x, off_y = (win_w - fit_w) // 2, (win_h - fit_h) // 2

    return win_w, win_h, fit_w, fit_h, off_x, off_y


# ----------------------------------------------------------------------
# PIXEL GRID PREPARATION (vectorized — this is what removes the "blocky
# squares" look: instead of blitting thousands of hard-edged rectangles,
# we build one small RGBA grid and let smoothscale() up-sample it, which
# blends neighbouring cells together into soft, organic patches.)
# ----------------------------------------------------------------------

def prepare_pixel_grid(display_rgb, fit_w, fit_h, block_size):
    """Down-sample the display image into a small (gh, gw, 3) color grid.
    Each cell is one reveal unit. The final image is always drawn
    separately at full resolution — this grid only drives the animation."""
    small = Image.fromarray(display_rgb).resize(
        (max(1, fit_w // block_size), max(1, fit_h // block_size)),
        Image.LANCZOS,
    )
    color_grid = np.array(small, dtype=np.uint8)  # (gh, gw, 3)
    gh, gw = color_grid.shape[0], color_grid.shape[1]
    return color_grid, gw, gh


def generate_reveal_order(gw, gh):
    """Return a (gh, gw) float32 grid of reveal_t values in [0, ~0.95)
    using a blend of center-outward, edge-to-center, clustered and
    scattered-random patterns, instead of a simple left-to-right sweep."""
    yy, xx = np.mgrid[0:gh, 0:gw].astype(np.float32)
    cx, cy = gw / 2.0, gh / 2.0
    dist = np.hypot(xx - cx, yy - cy)
    max_dist = dist.max() if dist.max() > 0 else 1.0
    dist_norm = dist / max_dist

    n = gw * gh
    flat_idx = np.arange(n)
    np.random.shuffle(flat_idx)

    reveal_t = np.zeros(n, dtype=np.float32)
    dist_flat = dist_norm.reshape(-1)

    g_center = flat_idx[: int(n * 0.35)]
    g_edge = flat_idx[int(n * 0.35): int(n * 0.60)]
    g_cluster = flat_idx[int(n * 0.60): int(n * 0.80)]
    g_random = flat_idx[int(n * 0.80):]

    jitter = np.random.uniform(-0.03, 0.03, size=g_center.shape).astype(np.float32)
    reveal_t[g_center] = np.clip(dist_flat[g_center] * 0.9 + jitter, 0.0, 0.9)

    jitter = np.random.uniform(-0.03, 0.03, size=g_edge.shape).astype(np.float32)
    reveal_t[g_edge] = np.clip((1.0 - dist_flat[g_edge]) * 0.9 + jitter, 0.0, 0.9)

    # Clustered patches: chunks of nearby-in-scan-order indices pop in together.
    cluster_size = 24
    for start in range(0, len(g_cluster), cluster_size):
        chunk = g_cluster[start:start + cluster_size]
        base_t = random.uniform(0.05, 0.85)
        reveal_t[chunk] = np.clip(
            base_t + np.random.uniform(-0.02, 0.02, size=chunk.shape), 0.0, 0.95
        )

    reveal_t[g_random] = np.random.uniform(0.0, 0.95, size=g_random.shape)

    return reveal_t.reshape(gh, gw)


def build_frame_surface(color_grid, reveal_grid, progress, fade_window, gw, gh):
    """Build the current animation frame as a small per-pixel-alpha
    pygame Surface (one pixel per reveal cell). The caller smoothscales
    this up, which is what blends cells into soft organic shapes instead
    of hard squares."""
    alpha = np.clip((progress - reveal_grid) / fade_window, 0.0, 1.0)
    alpha = (alpha * 255).astype(np.uint8)  # (gh, gw)

    rgba = np.dstack((color_grid, alpha))  # (gh, gw, 4)
    # pygame expects the array indexed as (x, y, channel) -> transpose.
    rgba_t = np.transpose(rgba, (1, 0, 2)).copy(order="C")
    surf = pygame.image.frombuffer(rgba_t.tobytes(), (gw, gh), "RGBA")
    return surf.convert_alpha()


def make_bloom(scaled_surface, scale=0.12, alpha=70):
    """Cheap glow: shrink the already-scaled frame way down, then blow it
    back up with smoothscale. The blur this produces is what gives the
    soft, premium bloom around bright/just-revealed areas."""
    w, h = scaled_surface.get_size()
    sw, sh = max(1, int(w * scale)), max(1, int(h * scale))
    small = pygame.transform.smoothscale(scaled_surface, (sw, sh))
    blurred = pygame.transform.smoothscale(small, (w, h))
    blurred.set_alpha(alpha)
    return blurred


# ----------------------------------------------------------------------
# PARTICLES
# ----------------------------------------------------------------------

class Particle:
    """A small ambient or burst particle used for atmosphere."""
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "size", "color")

    def __init__(self, x, y, vx, vy, life, size, color):
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.life = life
        self.max_life = life
        self.size = size
        self.color = color

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt
        return self.life > 0

    def alpha(self):
        return max(0, min(255, int(255 * (self.life / self.max_life))))


def make_ambient_particles(win_w, win_h, count):
    particles = []
    for _ in range(count):
        x, y = random.uniform(0, win_w), random.uniform(0, win_h)
        vx, vy = random.uniform(-4, 4), random.uniform(-6, -1)
        life = random.uniform(3, 8)
        size = random.uniform(1, 2.2)
        brightness = random.randint(60, 160)
        particles.append(Particle(x, y, vx, vy, life, size, (brightness,) * 3))
    return particles


def spawn_burst(x, y, count=4):
    burst = []
    for _ in range(count):
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(10, 40)
        vx, vy = math.cos(angle) * speed, math.sin(angle) * speed
        life = random.uniform(0.25, 0.6)
        size = random.uniform(1, 2.5)
        burst.append(Particle(x, y, vx, vy, life, size, (255, 240, 210)))
    return burst


# ----------------------------------------------------------------------
# DRAWING
# ----------------------------------------------------------------------

def draw_particles(surface, particles):
    for p in particles:
        a = p.alpha()
        if a <= 0:
            continue
        r, g, b = p.color
        s = int(p.size)
        pygame.draw.circle(surface, (r, g, b), (int(p.x), int(p.y)), max(1, s))


def draw_pixels(surface, color_grid, reveal_grid, progress, off_x, off_y,
                 fit_w, fit_h, gw, gh, glow_enabled):
    """Draw the current reveal state: build the small per-cell grid,
    smoothscale it up to full size (this is what blends neighbouring
    cells into soft shapes instead of hard squares), then blit it with
    an optional soft bloom layer underneath for a premium glow."""
    fade_window = 0.06  # fraction of progress over which a cell fades in
    small_frame = build_frame_surface(color_grid, reveal_grid, progress,
                                       fade_window, gw, gh)
    scaled = pygame.transform.smoothscale(small_frame, (fit_w, fit_h))

    if glow_enabled:
        bloom = make_bloom(scaled)
        surface.blit(bloom, (off_x, off_y), special_flags=pygame.BLEND_RGBA_ADD)

    surface.blit(scaled, (off_x, off_y))
    return scaled


def draw_final_image(surface, final_surf, off_x, off_y, brighten=0.0):
    """Blit the true, full-resolution source photograph. `brighten`
    (0-1) adds a subtle cinematic brightness lift on completion."""
    surface.blit(final_surf, (off_x, off_y))
    if brighten > 0:
        overlay = pygame.Surface(final_surf.get_size(), pygame.SRCALPHA)
        overlay.fill((255, 255, 255, int(40 * brighten)))
        surface.blit(overlay, (off_x, off_y), special_flags=pygame.BLEND_RGBA_ADD)


def draw_final_text(surface, font, text, win_w, text_y, fade_progress, spacing_extra=0):
    """Draw the caption with a fade-in and very subtle letter-spacing
    animation, plus a soft glow."""
    alpha = max(0, min(255, int(255 * fade_progress)))
    if alpha <= 0:
        return

    # Render each letter separately to allow subtle letter-spacing.
    letters = [font.render(ch, True, (255, 235, 225)) for ch in text]
    spacing = 2 + spacing_extra
    total_w = sum(l.get_width() for l in letters) + spacing * (len(letters) - 1)
    x = (win_w - total_w) // 2

    # Soft glow pass behind the text.
    glow_surf = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    gx = x
    for letter in letters:
        glow_letter = pygame.transform.smoothscale(
            letter, (int(letter.get_width() * 1.15), int(letter.get_height() * 1.15))
        )
        glow_letter.set_alpha(int(alpha * 0.35))
        glow_surf.blit(glow_letter, (gx - 4, text_y - 4))
        gx += letter.get_width() + spacing
    surface.blit(glow_surf, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)

    gx = x
    for letter in letters:
        letter.set_alpha(alpha)
        surface.blit(letter, (gx, text_y))
        gx += letter.get_width() + spacing


# ----------------------------------------------------------------------
# EASING
# ----------------------------------------------------------------------

def ease_out_cubic(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


# ----------------------------------------------------------------------
# VIDEO EXPORT
# ----------------------------------------------------------------------

def export_video(color_grid, reveal_grid, gw, gh, final_surf, win_w, win_h,
                  fit_w, fit_h, off_x, off_y, font, reveal_duration, fps, path):
    """Render the full animation offscreen and write it to an MP4 file
    using OpenCV, at the same resolution and quality as the live show."""
    try:
        import cv2
    except ImportError:
        print("OpenCV (opencv-python) is required for video export.")
        print("Install it with: pip install opencv-python")
        return

    os.makedirs(os.path.dirname(path), exist_ok=True)
    writer = cv2.VideoWriter(
        path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (win_w, win_h)
    )

    surface = pygame.Surface((win_w, win_h))
    total_frames = int(reveal_duration * fps) + int((TEXT_FADE_DURATION + 2) * fps)
    text_y = off_y + final_surf.get_height() + 40

    print(f"Exporting {total_frames} frames to {path} ...")
    for frame_i in range(total_frames):
        t = frame_i / fps
        surface.fill((BACKGROUND_BRIGHTNESS,) * 3)

        reveal_progress = ease_out_cubic(min(1.0, t / reveal_duration))
        draw_pixels(surface, color_grid, reveal_grid, reveal_progress, off_x, off_y,
                    fit_w, fit_h, gw, gh, SHOW_GLOW)

        if reveal_progress >= 1.0:
            brighten = min(1.0, (t - reveal_duration) / 1.0) if t > reveal_duration else 0
            draw_final_image(surface, final_surf, off_x, off_y, brighten)
            fade_t = max(0.0, min(1.0, (t - reveal_duration) / TEXT_FADE_DURATION))
            draw_final_text(surface, font, FINAL_TEXT, win_w, text_y, fade_t)

        frame_arr = pygame.surfarray.array3d(surface)
        frame_arr = np.transpose(frame_arr, (1, 0, 2))  # (H, W, 3)
        frame_bgr = frame_arr[:, :, ::-1]  # RGB -> BGR for OpenCV
        writer.write(frame_bgr.astype(np.uint8))

        if frame_i % fps == 0:
            print(f"  {frame_i // fps}s / {total_frames // fps}s rendered")

    writer.release()
    print(f"Export complete: {path}")
    print("Note: no audio track is included. To add background music,")
    print("merge the exported video with an audio file using ffmpeg, e.g.:")
    print(f'  ffmpeg -i "{path}" -i your_music.mp3 -c:v copy -shortest final.mp4')


# ----------------------------------------------------------------------
# MAIN APPLICATION
# ----------------------------------------------------------------------

def main():
    pygame.init()
    pygame.display.set_caption("A Memory, Rebuilt")

    print("Preparing your memory...")

    source_rgb = load_image(IMAGE_PATH)
    img_h, img_w = source_rgb.shape[0], source_rgb.shape[1]

    win_w, win_h, fit_w, fit_h, off_x, off_y = compute_display_size(img_w, img_h)
    screen = pygame.display.set_mode((win_w, win_h))

    # High-quality resize for the on-screen display copy (source data
    # itself is never modified or re-compressed).
    display_pil = Image.fromarray(source_rgb).resize((fit_w, fit_h), Image.LANCZOS)
    display_rgb = np.array(display_pil)
    final_surf = pygame.image.frombuffer(
        display_rgb.tobytes(), (fit_w, fit_h), "RGB"
    ).convert()

    color_grid, gw, gh = prepare_pixel_grid(display_rgb, fit_w, fit_h, PIXEL_SIZE)
    reveal_grid = generate_reveal_order(gw, gh)
    print(f"Prepared a {gw}x{gh} reveal grid ({gw * gh} cells).")

    font_path = pygame.font.match_font("georgia") or pygame.font.match_font("serif")
    font = pygame.font.Font(font_path, max(20, fit_h // 22))

    clock = pygame.time.Clock()
    ambient = make_ambient_particles(win_w, win_h, PARTICLE_COUNT) if SHOW_PARTICLES else []
    bursts = []

    start_time = time.time()
    fullscreen = False
    text_y = off_y + fit_h + 40
    running = True

    while running:
        dt = clock.tick(FPS) / 1000.0
        elapsed = time.time() - start_time
        raw_progress = min(1.0, elapsed / REVEAL_DURATION)
        progress = ease_out_cubic(raw_progress)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    start_time = time.time()
                elif event.key == pygame.K_s:
                    os.makedirs("output", exist_ok=True)
                    shot_path = f"output/screenshot_{int(time.time())}.png"
                    pygame.image.save(screen, shot_path)
                    print(f"Saved screenshot: {shot_path}")
                elif event.key == pygame.K_f:
                    fullscreen = not fullscreen
                    flags = pygame.FULLSCREEN if fullscreen else 0
                    screen = pygame.display.set_mode((win_w, win_h), flags)
                elif event.key == pygame.K_v:
                    export_video(color_grid, reveal_grid, gw, gh, final_surf,
                                 win_w, win_h, fit_w, fit_h, off_x, off_y,
                                 font, REVEAL_DURATION, EXPORT_FPS, EXPORT_PATH)

        screen.fill((BACKGROUND_BRIGHTNESS,) * 3)

        if SHOW_PARTICLES:
            ambient = [p for p in ambient if p.update(dt)]
            while len(ambient) < PARTICLE_COUNT:
                ambient.extend(make_ambient_particles(win_w, win_h, 1))
            draw_particles(screen, ambient)

            # Occasionally spawn a small burst near a freshly revealed area.
            if raw_progress < 1.0 and random.random() < 0.4:
                bx = off_x + random.uniform(0, fit_w)
                by = off_y + random.uniform(0, fit_h)
                bursts.extend(spawn_burst(bx, by, count=3))
            bursts = [p for p in bursts if p.update(dt)]
            draw_particles(screen, bursts)

        if raw_progress < 1.0:
            draw_pixels(screen, color_grid, reveal_grid, progress, off_x, off_y,
                        fit_w, fit_h, gw, gh, SHOW_GLOW)
            fade_progress = 0.0
        else:
            hold_elapsed = elapsed - REVEAL_DURATION
            brighten = min(1.0, hold_elapsed / 1.0)
            draw_final_image(screen, final_surf, off_x, off_y, brighten)
            fade_progress = max(0.0, min(1.0, hold_elapsed / TEXT_FADE_DURATION))

        draw_final_text(screen, font, FINAL_TEXT, win_w, text_y, fade_progress)

        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
